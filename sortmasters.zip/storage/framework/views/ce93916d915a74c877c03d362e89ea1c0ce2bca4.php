<?php $__env->startSection('style'); ?>
<link id="theme" rel="stylesheet" href="<?php echo e(asset('admin/css/style-helpdesk.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('background'); ?>
    <div class="background bg-dark">
		<img src="<?php echo e(asset('admin/images/bg.png')); ?>" alt="" class="full-opacity">
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <!-- Begin page content -->
        <div class="container">
            <div class="card rounded-2 border-0 mb-3 z3 signin-block">
                <div class="card-body pr-5 pl-5">
                <img style="margin-left:30%" src="<?php echo e(asset('favicon.png')); ?>" alt="logo">
                    <h1 class="display-4 text-center d-block">Admin Login</h1>
                    <br>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <input type="text" value="admin" name="type" style="display: none;"><!-- For checking the type of login form -->

                        <div class="form-group text-left float-label <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" >
							<input type="email" class="form-control"  name = "email" value="<?php echo e(old('email')); ?>"  required autofocus>
							<label>Email address</label>
						</div>
                        <div class="form-group text-left float-label">
                            <input type="password" class="form-control" name="password" required>
                            <label>Password</label>
                        </div>
                        <div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" id="customCheck1" <?php echo e(old('remember') ? 'checked' : ''); ?> name="remember">
							<label class="custom-control-label" for="customCheck1"> Remember Me</label>
						</div>
						<br>
                        <div>
							<button type="submit" class="btn btn-primary btn-block col">Login</button>
							<br>
						</div>
						<div class="text-left">
							<a href="<?php echo e(route('password.request')); ?>" class="">Forgot Password?</a>
						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>