<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Kelmas Ventures Ltd</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="description" content="We are a recruiting agency that recruits on behalf of cruise ships all over the world. We recruit, train and expose personels to work in different positions in the cruise ships. " />
    <meta name="keywords" content="Kelmas Ventures Ltd" />
    <meta name="author" content="" />
    <meta name="MobileOptimized" content="320" />
    <!--srart theme style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/animate.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/fonts.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/reset.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/owl.carousel.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/owl.theme.default.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('client/css/flaticon.css')); ?>" />
    <?php echo $__env->yieldContent('style'); ?>
    <?php echo $__env->yieldContent('responsive'); ?>
    <!-- favicon links -->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
    <?php echo $__env->make('client.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
        
     <!-- preloader Start -->
     <div id="preloader">
        <div id="status"><img src="<?php echo e(asset('client/images/header/loadinganimation.gif')); ?>" id="preloader_image" alt="loader">
        </div>
    </div>
    
    <!-- Top Scroll End -->
     <!-- Top Header Wrapper Start(except home page) -->
     <?php echo $__env->yieldContent('top_menu'); ?>
    <!-- Top Header Wrapper End -->
    <!-- Header Wrapper Start -->

    <?php echo $__env->yieldContent('menu'); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <!--main js file start-->
    <script src="https://unpkg.com/ionicons@4.5.5/dist/ionicons.js"></script>
    <script src="<?php echo e(asset('client/js/jquery_min.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/jquery.menu-aim.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/jquery.countTo.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/jquery.inview.min.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/jquery.magnific-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('client/js/modernizr.js')); ?>"></script>
    <?php echo $__env->yieldContent('custom_js'); ?>
    
    <!--main js file end-->
</body>
</html>