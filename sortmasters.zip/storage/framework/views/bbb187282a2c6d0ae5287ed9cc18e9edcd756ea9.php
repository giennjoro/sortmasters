<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/style-blue-header.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_left'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_right'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="row page-title-row">
                    <div class="col-8 col-md-6">
                        <h2 class="page-title">View agents</h2>
                        <p>Available agents </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Begin page content -->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="card border-0 rounded-0 mb-3">
                    <div class="card-header">
                    <h5 class="card-title">agents | <small>You have added the following agents</small></h5>
                    </div>
                    <div class="card-body">
                    <?php if(count($agents) > 0): ?>
                        <table class="table " id="dataTables-example">
                        <thead>
                            <tr>
                            <th>Agent</th>
                            <th>Phone</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd">
                            <td><a href="<?php echo e(asset($agent->image)); ?>"><img src="<?php echo e(asset($agent->image)); ?>" alt="agent_avatar" class="rounded-circle avatar50 figure"></a><?php echo e($agent->name); ?></td>
                                <td><?php echo e($agent->phone); ?></td>
                                <td>
                                <?php echo Form::open(['action' => ['AgentController@destroy',$agent->id], 'method' => 'POST', 'onsubmit' => 'return ConfirmDelete()']); ?>

                                    <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

                                    <div class="form-input">
                                        <button style="background:none; padding:0; color:red; border:none;" type="submit"><i class="fa fa-trash"></i></button>
                                        <a href="<?php echo e(route('agents.edit', ['id' => $agent->id])); ?>" class="btn btn-info btn-sm" style="background-color: transparent; border: 0px" ><i class="fa fa-eye" style="color: green"></i></a>
                                    </div>
                                <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    <?php else: ?>
                        <p>There are no agents to display.</p>
                    <?php endif; ?>
                    <!-- /.table-responsive --> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>