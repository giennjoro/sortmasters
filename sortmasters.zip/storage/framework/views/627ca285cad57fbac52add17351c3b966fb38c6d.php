<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/style-blue-header.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_left'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_right'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="row page-title-row">
                    <div class="col-8 col-md-6">
                        <h2 class="page-title">View Categories</h2>
                        <p>Available Categories </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Begin page content -->
    <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card border-0 rounded-0 mb-3">
                      <div class="card-header">
                        <h5 class="card-title">Categories | <small>You have added the following Categories</small></h5>
                      </div>
                      <div class="card-body">
                        <?php if(count($categories) > 0): ?>
                            <table class="table " id="dataTables-example">
                            <thead>
                                <tr>
                                <th>Title</th>
                                <th>Edit</th>
                                <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd">
                                <td><?php echo e($category->name); ?></td>
                                <td><a href="<?php echo e(route('categories.edit', ['slug' => $category->slug])); ?>" class="btn success"><i class="fa fa-edit"></i> Edit</a></td>
                                <td>
                                    <?php echo Form::open(['action' => ['CategoriesController@destroy',$category->slug], 'method' => 'POST', 'onsubmit' => 'return ConfirmDelete()']); ?>

                                        <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

                                        <?php echo e(Form::submit('Remove',['class'=>'btn btn-danger btn-sm fa fa-trash'])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        <?php else: ?>
                            <p>There are no categories to display.</p>
                        <?php endif; ?>
                        <!-- /.table-responsive --> 
                      </div>
                    </div>
                  </div>

            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>