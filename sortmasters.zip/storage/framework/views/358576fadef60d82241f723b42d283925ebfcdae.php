<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/style-blue-header.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_left'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_right'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="row page-title-row">
                    <div class="col-8 col-md-6">
                        <h2 class="page-title">View Properties</h2>
                        <p>Available Properties </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Begin page content -->
    <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card border-0 rounded-0 mb-3">
                      <div class="card-header">
                        <h5 class="card-title">Properties | <small>You have added the following Properties</small></h5>
                      </div>
                      <div class="card-body">
                        <?php if(count($properties) > 0): ?>
                            <table class="table " id="dataTables-example">
                            <thead>
                                <tr>
                                <th>Title</th>
                                <th>Date added</th>
                                <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd">
                                <td><?php echo e($property->title); ?></td>
                                <td><?php echo e(date('F d, Y', strtotime($property->created_at))); ?></td>
                                <td>
                                    <a href='/administrator/properties/<?php echo e($property->slug); ?>'>
                                        <button class="btn btn-success fa fa-eye">Show More</button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        <?php else: ?>
                            <p>There are no properties to display.</p>
                        <?php endif; ?>
                        <!-- /.table-responsive --> 
                      </div>
                    </div>
                  </div>

            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>