<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/style-blue-header.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_left'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_right'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="container">
                <div class="row page-title-row">
                    <div class="col-8 col-md-6">
                        <h2 class="page-title">View Admins</h2>
                        <p>Available Admins </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Begin page content -->
    <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card border-0 rounded-0 mb-3">
                      <div class="card-header">
                        <h5 class="card-title">Admins <small>Administrator details</small></h5>
                      </div>
                      <div class="card-body">
                        <?php if(count($admins) > 0): ?>
                            <table class="table " id="dataTables-example">
                            <thead>
                                <tr>
                                <th>Name </th>
                                <th>View</th>
                                <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd">
                                <td><?php echo e($admin->name); ?></td>
                                <td>
                                    <a href='/administrator/users/<?php echo e($admin->slug); ?>' ><button class="btn btn-success fa fa-eye"> View</button></a>
                                </td>
                                <td>
                                    <!-- <form action="route('users.destroy', ['slug' => $admin->slug])" method="delete">

                                    </form> -->
                                    <?php echo Form::open(['action' => ['UsersController@destroy',$admin->slug], 'method' => 'POST', 'onsubmit' => 'return ConfirmDelete()', 'id' => 'delete_user_form']); ?>

                                        <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

                                        <?php echo e(Form::submit('Remove',['class'=>'btn btn-danger'])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        <?php else: ?>
                            <p>There are no Admins to display.</p>
                        <?php endif; ?>
                        <!-- /.table-responsive -->
                      </div>
                    </div>
                  </div>

            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>