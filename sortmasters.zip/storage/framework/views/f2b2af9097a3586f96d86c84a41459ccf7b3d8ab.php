<?php $__env->startSection('style'); ?>
<link id="theme" rel="stylesheet" href="<?php echo e(asset('/admin/css/style-blue-header.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_left'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_left', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar_right'); ?>
    <?php echo $__env->make('admin.layouts.sidebar_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Begin page content -->
    <div class="container">
				
		<div class="row">
			<div class="col-12 col-md-12 col-lg-12  order-md-1">
				<div class="card rounded-0 border-0 mb-3">
					<div class="card-header">
						<div class="row">
							<div class="col-12">
								<h5 class="card-title"><?php echo e($property->title); ?> Images
									<a href="/administrator/properties" class="small">View all properties</a>
								</h5>
							</div>
						</div>
					</div>
					<div class="card-body p-0 ">
						<div class="swipegallery" itemscope itemtype="http://schema.org/ImageGallery">
							<div style="display: none;">
								<?php echo e($i = 0); ?>

								<?php echo e($len = count($images)); ?>

							</div>
							
							<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<figure itemprop="associatedMedia" itemscope >
									<a href="" itemprop="contentUrl" data-size="1060x640">
										<img src="<?php echo e(asset($image)); ?>" itemprop="thumbnail" alt="Image description" />
									</a>
									<?php if($i == 0): ?>
										<a href="#" class="btn btn-primary btn-xs"><i class="fa fa-check-circle"></i>cover photo</a>
									<?php else: ?>
										<a href="<?php echo e(route('cover_photo', ['slug' => $property->slug, 'image' => $i])); ?>" class="btn btn-primary btn-xs">Mark as cover photo</a>
									<?php endif; ?>
									<a href="<?php echo e(route('delete_photo', ['slug' => $property->slug, 'image' => $i])); ?>"><i class="fa fa-trash" style="color:red;" onclick="return ConfirmDelete()"></i></a>
								</figure>
								<div style="display: none;">
									<?php echo e($i++); ?>

								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>								
					</div>
				</div>
				<div class="card rounded-0 border-0 mb-3">
					<div class="card-header">
						<div class="row">
							<div class="col-12">
								<h5 class="card-title">
									<i class="icon fa fa-building text-primary mr-2"></i>
									Property Details
								</h5>
							</div>
						</div>
					</div>
					<div class="card-body ">
						<div class="list-unstyled userlist" style="padding: 5%">
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-success"></span>
										<div class="media">
											<div class="media-body">
												<h5>Title:</h5>
												<?php echo e($property->title); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-primary"></span>
										<div class="media">
											<div class="media-body">
												<h5>Category</h5>
												<?php echo e($property->category->name); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-warning"></span>
										<div class="media">
											<div class="media-body">
												<h5>Location</h5>
												<?php echo e($property->location); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-success"></span>
										<div class="media">
											<div class="media-body">
												<h5>Price:</h5>
												<?php echo e($property->price); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-primary"></span>
										<div class="media">
											<div class="media-body">
												<h5>Status:</h5>
												<?php echo e($property->status); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-warning"></span>
										<div class="media">
											<div class="media-body">
												<h5>Agent:</h5>
												<?php echo e($property->agent); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="list-item py-0 ">
								<div class="row">
									<div class="col-9 border-left pb-4 col-12 col-xl-12 col-sm-12  col-md-12 col-lg-12">
										<span class="timeline-bubble bg-info"></span>
										<div class="media">
											<div class="media-body">
												<h5>Description:</h5>
												<?php echo e($property->description); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-4" style="margin: 3%;">
									<a href='/administrator/properties/<?php echo e($property->slug); ?>/edit' ><button class="btn btn-success fa fa-edit"> Edit</button></a>
								</div>
								<div class="col-xs-2">

								</div>
								<div class="col-xs-4" style="margin: 3%;">
								<?php echo Form::open(['action' => ['PropertiesController@destroy',$property->slug], 'method' => 'POST', 'onsubmit' => 'return ConfirmDelete()']); ?>

									<?php echo e(Form::hidden('_method' ,'DELETE')); ?>

									<?php echo e(Form::submit('Remove',['class'=>'btn btn-danger fa fa-trash'])); ?>

								<?php echo Form::close(); ?>

								</div>
							</div>
						</div>
					</div>
					<br>
					<br>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>