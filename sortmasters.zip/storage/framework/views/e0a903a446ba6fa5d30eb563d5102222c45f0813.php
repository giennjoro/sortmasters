<!-- main menu -->
<div class="col-lg-7 col-md-8 col-sm-12 col-xs-12 center_responsive">
        <div class="header-area hidden-menu-bar stick" id="sticker">
            <!-- mainmenu start -->
            <div class="mainmenu">
                <ul class="float_left">
                    <li class="has-mega gc_main_navigation"><a href="/" class="gc_main_navigation">  Home</a>
                    </li>
                    <li class="has-mega gc_main_navigation"><a href="/about" class="gc_main_navigation">  About Us</a>
                    </li>
                    <li class="has-mega gc_main_navigation"><a href="/jobs" class="gc_main_navigation">  Jobs</a>
                    </li>
                    <li class="has-mega gc_main_navigation"><a href="/contact" class="gc_main_navigation">  Contact Us</a>
                    </li>
                </ul>
            </div>
            <!-- mainmenu end -->
            <!-- mobile menu area start -->
            <?php echo $__env->yieldContent('mobile_menu'); ?>
            
        </div>
</div>
    <!-- mobile menu area end -->
    